import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, ShoppingCart, BarChart3, Settings, User } from "lucide-react";

const HowToUse = () => {
  const steps = [
    {
      icon: User,
      title: "1. Create Your Account",
      description: "Sign up for free and set up your store profile with basic details like store name, GST, and contact information."
    },
    {
      icon: Package,
      title: "2. Add Your Inventory",
      description: "Use QR/barcode scanning or manual entry to add products. Include pricing, stock levels, and product details."
    },
    {
      icon: ShoppingCart,
      title: "3. Start Billing",
      description: "Use the POS system to add products to cart, generate invoices, and complete transactions quickly."
    },
    {
      icon: BarChart3,
      title: "4. Track Reports",
      description: "View daily and monthly reports, export to Excel, and analyze your sales performance."
    },
    {
      icon: Settings,
      title: "5. Customize Settings",
      description: "Adjust invoice format, tax rates, and other preferences to match your business needs."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto space-y-12">
          <div className="text-center space-y-4 animate-fade-in">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground">How to Use ShopMgmt</h1>
            <p className="text-xl text-muted-foreground">
              Get started in 5 easy steps
            </p>
          </div>

          <div className="space-y-6">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                      <span>{step.title}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground leading-relaxed pl-16">
                      {step.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <Card className="bg-muted">
            <CardContent className="p-8 space-y-4">
              <h2 className="text-2xl font-bold text-foreground">Need Help?</h2>
              <p className="text-muted-foreground">
                Our support team is here to help you get the most out of ShopMgmt. Contact us at 
                support@shopmgmt.com or call 1800-123-4567 for assistance.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default HowToUse;
