import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Target, Users, Zap } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto space-y-12">
          <div className="text-center space-y-4 animate-fade-in">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground">About ShopMgmt</h1>
            <p className="text-xl text-muted-foreground">
              Empowering local businesses with smart offline-first technology
            </p>
          </div>

          <Card className="animate-fade-in">
            <CardContent className="p-8 space-y-6">
              <h2 className="text-2xl font-bold text-foreground">Our Mission</h2>
              <p className="text-muted-foreground leading-relaxed">
                ShopMgmt is designed to help small and medium-sized retail businesses manage their operations 
                efficiently without worrying about internet connectivity. We believe that every shop owner 
                deserves access to modern billing and inventory management tools, regardless of their 
                technical expertise or infrastructure.
              </p>
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="text-center">
              <CardContent className="p-6 space-y-4">
                <div className="flex justify-center">
                  <Target className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground">Simple</h3>
                <p className="text-sm text-muted-foreground">
                  Easy to use interface designed for everyone
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6 space-y-4">
                <div className="flex justify-center">
                  <Zap className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground">Fast</h3>
                <p className="text-sm text-muted-foreground">
                  Quick billing and instant invoice generation
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6 space-y-4">
                <div className="flex justify-center">
                  <Users className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground">Reliable</h3>
                <p className="text-sm text-muted-foreground">
                  Works offline, syncs when online
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="animate-fade-in">
            <CardContent className="p-8 space-y-6">
              <h2 className="text-2xl font-bold text-foreground">Presented by n-dizi</h2>
              <p className="text-muted-foreground leading-relaxed">
                ShopMgmt is proudly developed and maintained by n-dizi, a technology company dedicated to 
                creating practical solutions for everyday business challenges. We're committed to continuous 
                improvement and value feedback from our users.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default About;
