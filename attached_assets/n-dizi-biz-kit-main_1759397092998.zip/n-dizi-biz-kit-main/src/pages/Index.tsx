import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowRight, BarChart3, Package, ShoppingCart, Zap } from "lucide-react";
import heroImage from "@/assets/hero-shop.jpg";
import inventoryIcon from "@/assets/feature-inventory.png";
import posIcon from "@/assets/feature-pos.png";
import reportsIcon from "@/assets/feature-reports.png";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-10"></div>
        <div className="container mx-auto px-4 py-20 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8 animate-fade-in">
              <h1 className="text-5xl lg:text-6xl font-bold text-foreground leading-tight">
                Smart Offline Billing for Local Stores
              </h1>
              <p className="text-xl text-muted-foreground">
                Manage your grocery, medical, or retail store effortlessly with our offline-first solution. 
                No internet? No problem.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/auth">
                  <Button size="lg" className="w-full sm:w-auto text-lg px-8">
                    Start Free <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link to="/about">
                  <Button size="lg" variant="outline" className="w-full sm:w-auto text-lg px-8">
                    Learn More
                  </Button>
                </Link>
              </div>
            </div>
            <div className="relative animate-fade-in">
              <img
                src={heroImage}
                alt="Shop Management Dashboard"
                className="rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold text-foreground">Powerful Features</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Everything you need to run your store efficiently
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="h-16 w-16 mb-4">
                  <img src={inventoryIcon} alt="Inventory" className="w-full h-full object-contain" />
                </div>
                <CardTitle>Smart Inventory</CardTitle>
                <CardDescription>
                  Scan QR codes, barcodes, or add items manually with ease
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="h-16 w-16 mb-4">
                  <img src={posIcon} alt="POS" className="w-full h-full object-contain" />
                </div>
                <CardTitle>Quick POS</CardTitle>
                <CardDescription>
                  Fast billing with instant invoice generation and printing
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="h-16 w-16 mb-4">
                  <img src={reportsIcon} alt="Reports" className="w-full h-full object-contain" />
                </div>
                <CardTitle>Detailed Reports</CardTitle>
                <CardDescription>
                  Daily and monthly sales reports with Excel export
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <Zap className="h-16 w-16 mb-4 text-primary" />
                <CardTitle>Offline First</CardTitle>
                <CardDescription>
                  Works perfectly without internet connection
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Card className="bg-gradient-hero text-primary-foreground">
            <CardContent className="p-12 text-center space-y-6">
              <h2 className="text-4xl font-bold">Ready to Get Started?</h2>
              <p className="text-xl opacity-90 max-w-2xl mx-auto">
                Join thousands of shop owners who trust ShopMgmt for their daily operations
              </p>
              <Link to="/auth">
                <Button size="lg" variant="secondary" className="text-lg px-8">
                  Try Now - It's Free
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
