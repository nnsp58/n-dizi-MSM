import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQ = () => {
  const faqs = [
    {
      question: "Does ShopMgmt work without internet?",
      answer: "Yes! ShopMgmt is built as an offline-first application. You can perform all core operations including billing, inventory management, and generating invoices without an internet connection. Data will sync automatically when you're back online."
    },
    {
      question: "What types of stores can use ShopMgmt?",
      answer: "ShopMgmt is perfect for grocery stores, medical shops, retail stores, and any small to medium-sized business that needs inventory and billing management."
    },
    {
      question: "Is the free plan really free forever?",
      answer: "Yes, our free plan includes all core features and will remain free. We'll be introducing premium features in the future with Razorpay integration for those who need advanced functionality."
    },
    {
      question: "Can I use a barcode scanner with ShopMgmt?",
      answer: "Absolutely! ShopMgmt supports QR code scanning, barcode scanning, and manual entry. You can use your device's camera or connect external scanners for faster product entry."
    },
    {
      question: "How do I export my reports?",
      answer: "You can export daily and monthly reports directly to Excel format from the Reports section. Just click the 'Export to Excel' button and download your data."
    },
    {
      question: "Is my data secure?",
      answer: "Yes, your data security is our priority. All data is stored locally on your device and encrypted. When syncing online, we use secure connections to protect your information."
    },
    {
      question: "Can I print invoices?",
      answer: "Yes, ShopMgmt generates professional invoices with your store details, GST information, and a watermark. You can print directly or share digitally with customers."
    },
    {
      question: "How do I get support?",
      answer: "You can reach our support team via email at support@shopmgmt.com or call our toll-free number 1800-123-4567. We also have detailed guides in the 'How to Use' section."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-16">
        <div className="max-w-3xl mx-auto space-y-8">
          <div className="text-center space-y-4 animate-fade-in">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-muted-foreground">
              Find answers to common questions about ShopMgmt
            </p>
          </div>

          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-card border border-border rounded-lg px-6"
              >
                <AccordionTrigger className="text-left font-semibold hover:text-primary">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default FAQ;
