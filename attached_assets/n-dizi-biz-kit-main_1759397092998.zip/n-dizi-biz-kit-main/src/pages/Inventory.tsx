import DashboardSidebar from "@/components/DashboardSidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Camera, Barcode } from "lucide-react";

const Inventory = () => {
  const products = [
    { id: 1, name: "Rice (1kg)", sku: "RIC001", stock: 50, price: 60, status: "In Stock" },
    { id: 2, name: "Wheat Flour (1kg)", sku: "WHE001", stock: 5, price: 45, status: "Low Stock" },
    { id: 3, name: "Sugar (1kg)", sku: "SUG001", stock: 30, price: 42, status: "In Stock" },
    { id: 4, name: "Cooking Oil (1L)", sku: "OIL001", stock: 0, price: 120, status: "Out of Stock" },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "In Stock":
        return "bg-success text-success-foreground";
      case "Low Stock":
        return "bg-warning text-warning-foreground";
      case "Out of Stock":
        return "bg-destructive text-destructive-foreground";
      default:
        return "";
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar />
      
      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Inventory Management</h1>
              <p className="text-muted-foreground">Manage your products and stock levels</p>
            </div>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Product
            </Button>
          </div>

          {/* Add Product Options */}
          <div className="grid md:grid-cols-3 gap-4">
            <Button variant="outline" className="h-24 flex-col space-y-2">
              <Camera className="h-8 w-8" />
              <span>Scan QR Code</span>
            </Button>
            <Button variant="outline" className="h-24 flex-col space-y-2">
              <Barcode className="h-8 w-8" />
              <span>Scan Barcode</span>
            </Button>
            <Button variant="outline" className="h-24 flex-col space-y-2">
              <Plus className="h-8 w-8" />
              <span>Manual Entry</span>
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search products..." className="pl-10" />
          </div>

          {/* Products List */}
          <Card>
            <CardHeader>
              <CardTitle>Products</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {products.map((product) => (
                  <div
                    key={product.id}
                    className="flex items-center justify-between p-4 bg-muted/50 rounded-lg hover:bg-muted transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="font-medium text-foreground">{product.name}</div>
                      <div className="text-sm text-muted-foreground">SKU: {product.sku}</div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <div className="font-medium text-foreground">₹{product.price}</div>
                        <div className="text-sm text-muted-foreground">Stock: {product.stock}</div>
                      </div>
                      <Badge className={getStatusColor(product.status)}>
                        {product.status}
                      </Badge>
                      <Button variant="ghost" size="sm">Edit</Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Inventory;
