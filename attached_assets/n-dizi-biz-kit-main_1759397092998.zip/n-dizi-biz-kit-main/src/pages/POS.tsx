import DashboardSidebar from "@/components/DashboardSidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Plus, Minus, Trash2, Receipt } from "lucide-react";

const POS = () => {
  const cartItems = [
    { id: 1, name: "Rice (1kg)", price: 60, quantity: 2 },
    { id: 2, name: "Wheat Flour (1kg)", price: 45, quantity: 1 },
    { id: 3, name: "Sugar (1kg)", price: 42, quantity: 3 },
  ];

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const tax = subtotal * 0.05; // 5% tax
  const total = subtotal + tax;

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar />
      
      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Products Section */}
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">Point of Sale</h1>
                <p className="text-muted-foreground">Quick billing and checkout</p>
              </div>

              <Input placeholder="Search or scan product..." className="text-lg h-12" />

              <div className="grid md:grid-cols-3 gap-4">
                {["Rice", "Wheat Flour", "Sugar", "Oil", "Tea", "Coffee", "Salt", "Milk", "Bread"].map((product) => (
                  <Button
                    key={product}
                    variant="outline"
                    className="h-24 text-lg font-medium hover:bg-primary hover:text-primary-foreground"
                  >
                    {product}
                  </Button>
                ))}
              </div>
            </div>

            {/* Cart Section */}
            <div>
              <Card className="sticky top-8">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Cart</span>
                    <Badge variant="secondary">{cartItems.length} items</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Cart Items */}
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {cartItems.map((item) => (
                      <div key={item.id} className="space-y-2">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="font-medium text-sm">{item.name}</div>
                            <div className="text-sm text-muted-foreground">₹{item.price}</div>
                          </div>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Button variant="outline" size="icon" className="h-8 w-8">
                              <Minus className="h-4 w-4" />
                            </Button>
                            <span className="w-8 text-center font-medium">{item.quantity}</span>
                            <Button variant="outline" size="icon" className="h-8 w-8">
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                          <div className="font-medium">₹{item.price * item.quantity}</div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  {/* Totals */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span className="font-medium">₹{subtotal}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Tax (5%)</span>
                      <span className="font-medium">₹{tax.toFixed(2)}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between">
                      <span className="font-semibold text-lg">Total</span>
                      <span className="font-bold text-lg text-primary">₹{total.toFixed(2)}</span>
                    </div>
                  </div>

                  <Button className="w-full h-12 text-lg">
                    <Receipt className="h-5 w-5 mr-2" />
                    Generate Invoice
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default POS;
