import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";

const Terms = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="text-center space-y-4 animate-fade-in">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground">Terms & Conditions</h1>
            <p className="text-muted-foreground">Last updated: January 2025</p>
          </div>

          <Card>
            <CardContent className="p-8 space-y-6">
              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-foreground">1. Acceptance of Terms</h2>
                <p className="text-muted-foreground leading-relaxed">
                  By accessing and using ShopMgmt, you accept and agree to be bound by these Terms and 
                  Conditions. If you do not agree to these terms, please do not use our service.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-foreground">2. Use License</h2>
                <p className="text-muted-foreground leading-relaxed">
                  ShopMgmt grants you a personal, non-exclusive, non-transferable license to use the 
                  software for your business operations. You may not modify, distribute, or create 
                  derivative works based on ShopMgmt.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-foreground">3. User Responsibilities</h2>
                <p className="text-muted-foreground leading-relaxed">
                  You are responsible for maintaining the confidentiality of your account credentials and 
                  for all activities that occur under your account. You agree to notify us immediately of 
                  any unauthorized use of your account.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-foreground">4. Data Accuracy</h2>
                <p className="text-muted-foreground leading-relaxed">
                  While ShopMgmt strives to ensure accuracy in billing and inventory management, you are 
                  responsible for verifying the accuracy of all data entered into the system and all 
                  transactions processed.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-foreground">5. Service Availability</h2>
                <p className="text-muted-foreground leading-relaxed">
                  We strive to provide uninterrupted access to ShopMgmt, but we do not guarantee that the 
                  service will always be available or error-free. We reserve the right to modify, suspend, 
                  or discontinue any aspect of the service at any time.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-foreground">6. Limitation of Liability</h2>
                <p className="text-muted-foreground leading-relaxed">
                  ShopMgmt and n-dizi shall not be liable for any indirect, incidental, special, 
                  consequential, or punitive damages resulting from your use of or inability to use the 
                  service.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-foreground">7. Changes to Terms</h2>
                <p className="text-muted-foreground leading-relaxed">
                  We reserve the right to modify these terms at any time. We will notify users of any 
                  material changes via email or through the application. Continued use of ShopMgmt after 
                  such modifications constitutes acceptance of the updated terms.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-foreground">8. Contact Information</h2>
                <p className="text-muted-foreground leading-relaxed">
                  For questions about these Terms and Conditions, please contact us at 
                  support@shopmgmt.com or call 1800-123-4567.
                </p>
              </section>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Terms;
