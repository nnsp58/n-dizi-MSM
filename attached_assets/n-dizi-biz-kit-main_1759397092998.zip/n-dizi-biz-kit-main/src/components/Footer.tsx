import { Link } from "react-router-dom";
import { Facebook, Instagram, Phone, Mail } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-muted border-t border-border mt-20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <h3 className="font-bold text-lg text-foreground">ShopMgmt</h3>
            <p className="text-sm text-muted-foreground">
              Smart offline billing for local stores
            </p>
            <p className="text-xs text-muted-foreground">
              Presented by <span className="font-semibold">n-dizi</span>
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-semibold text-foreground">Quick Links</h4>
            <div className="flex flex-col space-y-2">
              <Link to="/about" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                About Us
              </Link>
              <Link to="/faq" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                FAQ
              </Link>
              <Link to="/how-to-use" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                How to Use
              </Link>
            </div>
          </div>

          {/* Legal */}
          <div className="space-y-4">
            <h4 className="font-semibold text-foreground">Legal</h4>
            <div className="flex flex-col space-y-2">
              <Link to="/privacy" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Terms & Conditions
              </Link>
            </div>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h4 className="font-semibold text-foreground">Contact Us</h4>
            <div className="flex flex-col space-y-2">
              <a href="tel:1800-123-4567" className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center space-x-2">
                <Phone className="h-4 w-4" />
                <span>1800-123-4567</span>
              </a>
              <a href="mailto:support@shopmgmt.com" className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center space-x-2">
                <Mail className="h-4 w-4" />
                <span>support@shopmgmt.com</span>
              </a>
            </div>
            <div className="flex space-x-4 pt-2">
              <a href="https://wa.me/918012345678" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                <FaWhatsapp className="h-5 w-5" />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        {/* AdSense Placeholder */}
        <div className="mt-8 p-4 bg-secondary rounded-lg border border-border text-center">
          <p className="text-xs text-muted-foreground">Advertisement Space</p>
        </div>

        {/* Copyright */}
        <div className="mt-8 pt-8 border-t border-border text-center">
          <p className="text-sm text-muted-foreground">
            © 2025 ShopMgmt. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
